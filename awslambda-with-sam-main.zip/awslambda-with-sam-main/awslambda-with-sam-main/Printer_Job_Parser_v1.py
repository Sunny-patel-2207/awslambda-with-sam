import tabula
import csv
import json
import os
import boto3
import requests
import datetime
import pytz

def convertPdfToCSV(pdf_file, csv_file):
    # To extract weigh master details
    pd = tabula.read_pdf( pdf_file, pages='1',stream=True, multiple_tables=False, silent=True, area=[ 283.433,24.48,372.938,154.53 ])

    for k in range(len(pd)):
        pd[k].to_csv(csv_file, mode ='a', index = False)

    # To extract details above the table
    pd = tabula.read_pdf( pdf_file, pages='1',stream=True, multiple_tables=False, silent=True ,area=[ [31.748,393.21,142.673,578.34], [69.998,29.07,141.908,120.87], [69.233,123.93,141.143,320.535] ])

    for j in range(len(pd)):
        pd[j].to_csv(csv_file, mode ='a', index = False)

    # To extract table details 
    pd = tabula.read_pdf( pdf_file, pages='1',lattice=True, guess=False, silent=True )

    for i in range(len(pd)-2):
        pd[i].to_csv(csv_file, mode ='a', index = False)     

def process_csv(file_location, file_date_time):
    file = open(file_location)
    csv_data = csv.reader(file)
    csv_list = list(csv_data)

    ticket_index = [] #Added for common logic to process both inbound and outbound tickets
    material_data = [] #Added for common logic to process both inbound and outbound tickets
    print_date_index = 0 #Added for common logic to process both inbound and outbound tickets
    customer_index = 0
    material_index = []
    acknowledgements_index = [] #Changed logic here for outbound second type ticket
    weigh_master_index = [] #Added for common logic to process both inbound and outbound tickets
    
    TicketNo = ''
    TicketType = 'Inbound'
    PrintDate = ''
    CustomerName = ''
    FacilityName = ''
    CustomerAddress = ''
    FacilityAddress = ''
    DateIn = ''
    DateOut = ''
    TimeIn = ''
    TimeOut = ''
    HaulerName = ''
    LicensePlate = ''
    ContainerTrailerNo = ''
    GrossWeight = ''
    TareWeight = ''
    NetWeight = ''
    ServiceAgreement = ''
    JobNo = ''
    ReleaseNo = ''
    Notes = ''
    Weighmaster = ''
    Weightmaster_flag = False

    # Extract data for different fields
    for row in range(len(csv_list)):
        for col in range(len(csv_list[row])):

            if "ACKNOWLEDGEMENTS" in csv_list[row][col] and row != 0:
                acknowledgements_index.append(row)
                material_index.append(row)

            elif "WEIGHMASTER" in csv_list[row][col] and Weightmaster_flag == False:
                Weightmaster_flag = True
                weigh_master_index.append(row)
                if row != 0 and "ACKNOWLEDGEMENTS" not in csv_list[row-1][col]:
                    Weighmaster = csv_list[row-1][0]

            elif "Tkt No" in csv_list[row][col]:
                ticket_index.append(row)
                TicketNo = csv_list[row][col].split("Tkt No")[1]

            # Added for outbound tickets
            elif "Ticket #:" in csv_list[row][col]:
                ticket_index.append(row)
                TicketNo = csv_list[row][col].split("Ticket #:")[1]
                
            elif "Print Date:" in csv_list[row][col]:
                PrintDate = csv_list[row][col].split("Print Date:")[1]
                print_date_index = row
                FacilityName = csv_list[row+1][col]

            elif "CUSTOMER" == csv_list[row][col]:
                customer_index = row
                CustomerName = csv_list[row+1][col]
     
            elif "DATE IN" == csv_list[row][col]:
                DateIn = csv_list[row][col+1]
                
            elif "TIME IN" == csv_list[row][col]:
                #time_in_index = row
                TimeIn = csv_list[row][col+1]
                
            elif "DATE OUT" == csv_list[row][col]:
                DateOut = csv_list[row][col+1]

            elif "TIME OUT" == csv_list[row][col]:
                TimeOut = csv_list[row][col+1]

            elif "NAME" == csv_list[row][col]:
                HaulerName = csv_list[row][col+1]
                if 'AGREEMENT' not in csv_list[row+1][0] and 'TIME IN' not in csv_list[row+1][0]:
                    HaulerName += ' ' + csv_list[row+1][0]
            
            elif "LICENSE PLATE" == csv_list[row][col]:
                LicensePlate = csv_list[row][col+1]

            elif "CONTAINER" in csv_list[row][col]:
                if len(csv_list[row]) != col+1:
                    ContainerTrailerNo += ' ' + csv_list[row][col+1]
            
            elif "TRAILER #" == csv_list[row][col]:
                ContainerTrailerNo +=  ' ' + csv_list[row][col+1]
                
            elif "GROSS" == csv_list[row][col]:
                GrossWeight = csv_list[row][col+1]

            elif "TARE" == csv_list[row][col]:
                TareWeight = csv_list[row][col+1]

            elif "NET" == csv_list[row][col]:
                NetWeight = csv_list[row][col+1]

            elif "AGREEMENT" in csv_list[row][col]:
                ServiceAgreement = csv_list[row][col+1] if 'Unnamed' not in csv_list[row][col+1] else ''   
                for i in range(1, 5):    
                    if 'TIME IN' not in csv_list[row+i][0]:
                        ServiceAgreement += ' ' + csv_list[row+i][0]
                    else:
                        break

            elif "JOB" in csv_list[row][col]:
                TicketType = 'Inbound'
                JobNo = csv_list[row][col+1]
                if csv_list[row+1][0] != 'DATE OUT':
                    JobNo += ' ' + csv_list[row+1][0]
                
            elif "RELEASE" in csv_list[row][col]:
                TicketType = 'Outbound'
                ReleaseNo = csv_list[row][col+1]
                if csv_list[row+1][0] != 'DATE OUT':
                    ReleaseNo += ' ' + csv_list[row+1][0]

            elif "NOTES" == csv_list[row][col]:
                Notes = csv_list[row][col+1]
                if csv_list[row+1][0] != 'TIME OUT':
                    Notes += ' ' + csv_list[row+1][0]

            else:
                continue

    # Extract customer address
    for x in range(customer_index + 2, ticket_index[1]):
        if CustomerAddress == '':
            CustomerAddress = csv_list[x][0]
        else:
            CustomerAddress += ", " + csv_list[x][0]

    # Extract facility address
    for y in range(print_date_index + 2, customer_index):
        if FacilityAddress == '':
            FacilityAddress = csv_list[y][0]
        else:
            FacilityAddress += ", " + csv_list[y][0]
    
    headerData = dict()
    headerData["ScaleTicketNo"] = str(TicketNo).strip()
    headerData["PrintDate"] = str(PrintDate).strip()
    headerData["CustomerName"] = str(CustomerName).strip()
    headerData["FacilityName"] = str(FacilityName).strip()
    headerData["CustomerAdderess"] = str(CustomerAddress).strip()
    headerData["FacilityAdderess"] = str(FacilityAddress).strip()
    headerData["DateIn"] = str(DateIn).strip()
    headerData["TimeIn"] = str(TimeIn).strip()
    headerData["DateOut"] = str(DateOut).strip()
    headerData["TimeOut"] = str(TimeOut).strip()
    headerData["HaulerName"] = str(HaulerName).strip()
    headerData["LicensePlate"] = str(LicensePlate).strip()
    headerData["ContainerTrailerNo"] = str(ContainerTrailerNo).strip()
    headerData["GrossWeight"] = str(GrossWeight).strip()
    headerData["TareWeight"] = str(TareWeight).strip()
    headerData["NetWeight"] = str(NetWeight).strip()
    headerData["ServiceAgreement"] = str(ServiceAgreement).strip()
    headerData["JOB_No"] = str(JobNo).strip()
    headerData["Release_No"] = str(ReleaseNo).strip()
    headerData["Notes"] = str(Notes).strip()
    headerData["WeightMaster"] = str(Weighmaster).strip()
    headerData["TicketDiscriptions"] = []

    # Acquiring material data 
    for row in range(material_index[0] , len(csv_list)):
        for col in range(len(csv_list[row])):
            if "ACKNOWLEDGEMENTS" not in csv_list[row][col] and "WEIGHMASTER" not in csv_list[row][col] and "DRIVER'S SIGNATURE" not in csv_list[row][col] and csv_list[row][col] != '' and csv_list[row][col] != Weighmaster :
                material_data.append(csv_list[row][col])

    # Material data related variables and list
    material_count = 0
    material_qty_list = []
    material_name_list = []
    material_weight_list = []
    material_container_list = []
    container_type = ''

    # To separate data as per their type like name, quantity , weight and container type
    for data in material_data:
        if 'KG' in data and data != Weighmaster:
            material_count += 1
            material_weight_list.append(data)

        elif 'KG' not in data and data != 'Kg' and data.isnumeric() == False and data != Weighmaster:
            material_name_list.append(data)

        elif data.isnumeric() == True:
            material_qty_list.append(data)

        elif data == 'Kg':
            material_container_list.append(data)

    if len(material_name_list) > material_count:
        for i in range(0, material_count):
            name = material_name_list[i].strip()
            if name[-3:] == 'and':
                material_name_list[i] = material_name_list[i] + ' ' + material_name_list[i+1]
                material_name_list.pop(i+1) # Remove the remaining name of material 
            
    # Preparing lists of material data to be inserted as JSON    
    
    for i in range(0, material_count):
        if len(material_qty_list) == 0:
            material_qty_list.append('')
        elif len(material_qty_list) < material_count and len(material_qty_list) != 0:
                material_qty_list.append('')
    
    for i in range(0, material_count):
        if len(material_container_list) == 0:
            material_container_list.append('')
        elif len(material_container_list) < material_count and len(material_container_list) != 0:
            container_type = material_container_list[0]
            material_container_list.append(container_type)
 
    #Preparing JSON data for material
    for i in range(0, material_count):
        
        materialData = dict()
        material = material_name_list[i]
        materialData["MaterialName"] = str(material).strip()

        container_type = material_container_list[i]
        materialData["ContainerType"] =str(container_type).strip()

        qty = material_qty_list[i]
        materialData["Qty"] = str(qty).strip()

        weight = material_weight_list[i]
        materialData["WeightUOM"] = str(weight).strip()
        
        headerData["TicketDiscriptions"].append(materialData)

    ticketNo = headerData["ScaleTicketNo"]
    processedFilePath = str(file_date_time) + "_" + ticketNo + ".pdf"

    ticketData = dict()
    ticketData["ticketNo"] = ticketNo
    ticketData["ticketType"] = TicketType
    ticketData["dateIn"] = headerData["DateIn"]
    #ticketData["filePath"] = "amcs-cietrade-scale-ticket-parser/Processed/" + processedFilePath
    ticketData["filePath"] = "bmv-konnected-printer-files/Processed/" + processedFilePath
    ticketData["data"] = headerData

    json_string = json.dumps(ticketData)

    return json_string, processedFilePath  

def send_data_to_urban_server(jsonData):
    # Production endpoint URL
    #x = requests.post("https://urbanprodapi.konnectedtechnology.com/api/AmcsToCieTrade/add-update-unprocessed-ticket-data", data=jsonData, headers={"Content-type": "application/json"})
    
    # Sandbox endpoint URL
    x = requests.post("https://urbanstageapi.konnectedtechnology.com/api/AmcsToCieTrade/add-update-unprocessed-ticket-data", data=jsonData, headers={"Content-type": "application/json"})
    return x.status_code

def send_data_to_cietrade_server():
    # Production endpoint URL
    #x = requests.put("https://urbanprodapi.konnectedtechnology.com/api/AmcsToCieTrade/push-unprocessed-data-into-cietrade?updateKey=31d4b0cb036723f463383de")
    
    # Sandbox endpoint URL
    x = requests.put("https://urbanstageapi.konnectedtechnology.com/api/AmcsToCieTrade/push-unprocessed-data-into-cietrade?updateKey=31d4b0cb036723f463383de")
    return x.status_code

def lambda_handler(event, context):
    print("Running...\n")

    # Create s3 resource
    s3client = boto3.client('s3',
        aws_access_key_id='AKIAUX5E4XDJHPF75HCR',
        aws_secret_access_key='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',
        region_name = 'us-east-1'
        )

    # Create s3 resource
    s3resource = boto3.resource('s3',
        aws_access_key_id='AKIAUX5E4XDJHPF75HCR',
        aws_secret_access_key='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',
        region_name = 'us-east-1'
        )
    
    #FileDir = "C:/Users/baps/Documents/Download/" # Local directory
    FileDir = "/mnt/access/Download/" # Instance directory
    Bucket = "bmv-konnected-printer-files"
    
    bucket = s3resource.Bucket(Bucket)

    for obj in bucket.objects.filter(Delimiter='/', Prefix='Unprocessed/'):
        if obj.key != 'Unprocessed/':
            print(obj.key)
    
            FileName = obj.key.split("/")[1]
            S3FilePath = obj.key
            
            PdfFilePath = FileDir + FileName
            FileNameWithoutExtension = FileName.split(".pdf")[0]
            CsvFilePath = FileDir + FileNameWithoutExtension + ".csv"
            pst = pytz.timezone('America/Los_Angeles')
            today = datetime.datetime.now(pst).date()
        
            try:
                #check date wise folder exist or not
                path = "Processed/" + str(today)
                resp = "CommonPrefixes" in s3client.list_objects(Bucket=Bucket, Prefix=path, Delimiter='/', MaxKeys=1)
                if resp == False:
                    s3client.put_object(Bucket=Bucket, Key=(path + '/'))
                        
                #download the file from S3
                s3client.download_file(Bucket, S3FilePath, PdfFilePath)
        
                #convert to CSV
                convertPdfToCSV(PdfFilePath, CsvFilePath)
                            
                #processing on CSV
                scale_ticket_json, processed_file_path = process_csv(CsvFilePath, str(today) + "/" + str(FileName.split("_")[0]) )
                print("File Processed :: ", scale_ticket_json)     
                
                #send data to server
                res = send_data_to_urban_server(scale_ticket_json)
                print("Send Data :: ", res)
                
                if res == 200:
                    s3filePath = "Processed/" + processed_file_path
                    s3client.upload_file(PdfFilePath, Bucket, s3filePath, ExtraArgs={'ACL': 'public-read'})
        
                    # Remove file from Unprocessed S3 bucket
                    s3client.delete_object(Bucket=Bucket, Key=S3FilePath)
        
                    # Cietrade data push service
                    push_res = send_data_to_cietrade_server()
                    print("Data Pushing :: ", push_res)
        
                elif res == 206:
                    #check date wise folder exist or not
                    path = "Exception/" + str(today)
                    resp = "CommonPrefixes" in s3client.list_objects(Bucket=Bucket, Prefix=path, Delimiter='/', MaxKeys=1)
                    if resp == False:
                        s3client.put_object(Bucket=Bucket, Key=(path + '/'))
        
                    # Upload file into Exception S3 bucket
                    s3filePath = "Exception/" + str(today) + "/" + FileName
                    s3client.upload_file(PdfFilePath, Bucket, s3filePath, ExtraArgs={'ACL': 'public-read'})
                
                    # Remove file from Unprocessed S3 bucket
                    s3client.delete_object(Bucket=Bucket, Key=S3FilePath)
        
                else:
                    continue
                
                # Remove PDF & CSV files from Instance                 
                os.remove(CsvFilePath)
                os.remove(PdfFilePath)
        
            except Exception as ex:
                print("\n Ex :: ", ex)
                #check date wise folder exist or not
                path = "Exception/" + str(today)
                resp = "CommonPrefixes" in s3client.list_objects(Bucket=Bucket, Prefix=path, Delimiter='/', MaxKeys=1)
                if resp == False:
                    s3client.put_object(Bucket=Bucket, Key=(path + '/'))
        
                # Upload file into Exception S3 bucket
                s3filePath = "Exception/" + str(today) + "/" + FileName
                s3client.upload_file(PdfFilePath, Bucket, s3filePath, ExtraArgs={'ACL': 'public-read'})
            
                # Remove file from Unprocessed S3 bucket
                s3client.delete_object(Bucket=Bucket, Key=S3FilePath)
        
                # Remove PDF & CSV files from Instance
                os.remove(CsvFilePath)
                os.remove(PdfFilePath)
